const heartLayer = document.getElementById('heartLayer');

function makeHeart() {
  const heart = document.createElement('span');
  heart.className = 'floating-heart';
  heart.textContent = Math.random() > 0.5 ? '♥' : '♡';
  heart.style.left = `${Math.random() * 100}%`;
  heart.style.fontSize = `${14 + Math.random() * 25}px`;
  heart.style.animationDuration = `${6 + Math.random() * 6}s`;
  heartLayer.appendChild(heart);
  heart.addEventListener('animationend', () => heart.remove());
}

setInterval(makeHeart, 420);

const audio = document.getElementById('birthdayAudio');
const playButton = document.getElementById('playButton');
const musicNote = document.getElementById('musicNote');

playButton.addEventListener('click', async () => {
  if (audio.paused) {
    try {
      await audio.play();
      playButton.textContent = 'Ⅱ Pause song';
      musicNote.textContent = 'Enjoy the music! 💗';
    } catch {
      musicNote.textContent = 'The song could not play. Check that its-you.mp3 is in this folder.';
    }
  } else {
    audio.pause();
    playButton.textContent = '▶ Play song';
    musicNote.textContent = 'Music paused';
  }
});

audio.addEventListener('ended', () => {
  playButton.textContent = '▶ Play song';
});
